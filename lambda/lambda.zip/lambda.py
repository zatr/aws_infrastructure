import json


def start_test_runner(software_version):
    print("Received event: " + software_version)
